package com.libai.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;
import java.io.*;
import java.nio.charset.StandardCharsets;

@SpringBootApplication(scanBasePackages = "com.libai.test")
@RestController
public class SpringBootHttpsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootHttpsApplication.class, args);
    }

    @RequestMapping("/name/{name}")
    public String hello(@PathVariable String name) {
        return "Howdy " + name + ", have a good day!!";
    }

    @GetMapping("/hello")
    public String hello() {
        return "hello world";
    }

}