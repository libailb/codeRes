package com.libai.test.file;

import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;

@RestController
public class FileDealController {

    @GetMapping("/download/{filename}")
    @ResponseBody
    public String download(HttpServletRequest request, HttpServletResponse response, @PathVariable String filename) {
        //下载的文件路径
        String filePath = "./file/";
        //使用流的形式下载文件
        try (
                InputStream is = this.getClass().getResourceAsStream(filePath);
                OutputStream os = response.getOutputStream();
        ) {
            byte[] bytes = StreamUtils.copyToByteArray(is);
            response.reset();
            response.setContentType("application/octet-stream");
            response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1));
            response.addHeader("Content-Length", "" + bytes.length);
            os.write(bytes);
            os.flush();
            return "";
        } catch (Exception e) {
            return "file download error";
        }
    }
}
